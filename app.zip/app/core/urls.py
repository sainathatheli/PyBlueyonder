
from rest_framework import routers
from core import views

router = routers.DefaultRouter()
router.register('students', views.StudentViewSet)
router.register('universities', views.UniversityViewSet)

urlpatterns = router.urls